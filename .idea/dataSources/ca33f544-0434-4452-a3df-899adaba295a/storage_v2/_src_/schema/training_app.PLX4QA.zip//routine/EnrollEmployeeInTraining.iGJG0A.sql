create
    definer = owen@localhost procedure EnrollEmployeeInTraining(IN p_employee_id bigint, IN p_training_id bigint,
                                                                IN p_start_date date, IN p_end_date date)
BEGIN
    INSERT INTO employees_trainings (employee_id, training_id, status, start_date, end_date)
    VALUES (p_employee_id, p_training_id, 'Scheduled', p_start_date, p_end_date);
END;

